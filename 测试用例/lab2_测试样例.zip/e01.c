int main() {
    int a;
    int b;
    int c;
    a = 1;
    println_int(a);
    b = 2;
    println_int(b);
    c = 114514;
    println_int(c);
    return 0;
}