int main() {
    int jksbnjklvbnzjk;
    int _ANJDFnjkl_jnnjk121212;
    int ___________1371909014;
    int XXnjdj782908jsjk__njks9;
    int ssbdhqwa;
    int vsvsoijiop;

    jksbnjklvbnzjk = 114;
    _ANJDFnjkl_jnnjk121212 = 514;
    ssbdhqwa = jksbnjklvbnzjk + _ANJDFnjkl_jnnjk121212;
    ___________1371909014 = jksbnjklvbnzjk - _ANJDFnjkl_jnnjk121212;
    XXnjdj782908jsjk__njks9 = jksbnjklvbnzjk * _ANJDFnjkl_jnnjk121212;
    vsvsoijiop = jksbnjklvbnzjk / _ANJDFnjkl_jnnjk121212;
    println_int(jksbnjklvbnzjk);
    println_int(_ANJDFnjkl_jnnjk121212);
    println_int(ssbdhqwa);
    println_int(___________1371909014);
    println_int(XXnjdj782908jsjk__njks9);
    println_int(vsvsoijiop);
    return 0;
}
