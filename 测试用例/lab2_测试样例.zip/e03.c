int main() {
    int _0893127890;
    int hgbahjkf;
    int or;
    int and;
    int xor;

    _0893127890 = 114;
    hgbahjkf = 514;
    or = _0893127890 | hgbahjkf;
    and = _0893127890 & hgbahjkf;
    xor = _0893127890 ^ hgbahjkf;
    println_int(or);
    println_int(and);
    println_int(xor);
    return 0;
}