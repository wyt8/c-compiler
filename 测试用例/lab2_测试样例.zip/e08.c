int main() {
  int var0;
  int var1;
  int le;
  int lt;
  int ge;
  int gt;
  int ne;
  int eq;

  var0 = 114;
  var1 = 514;
  le = var0 <= var1;
  lt = var0 < var1;
  ge = var0 >= var1;
  gt = var0 > var1;
  ne = var0 != var1;
  eq = var0 == var1;
  println_int(var0);
  println_int(var1);
  println_int(le);
  println_int(lt);
  println_int(ge);
  println_int(gt);
  println_int(ne);
  println_int(eq);
  return 0;
}
