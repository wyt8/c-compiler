int main() {
  int a = 1, b = 2, c;
  println_int(a);
  println_int(b);
  c = 114514;
  println_int(c);
  return 0;
}
