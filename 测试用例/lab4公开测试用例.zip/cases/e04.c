int main() {
    int a = 5;
    if (a % 2 == 0) {
        println_int(0);
    } else {
        println_int(1);
    }
    return 0;
}
